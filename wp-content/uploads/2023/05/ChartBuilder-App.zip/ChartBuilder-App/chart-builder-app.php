/**
* A PHP file that serves as the entry point for your plugin,
* where you define the plugin metadata and include the main plugin file.
*/