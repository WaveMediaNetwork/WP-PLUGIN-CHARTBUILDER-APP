/**
* A PHP file that contains the template for the account settings page,
* where users can update their account information.
*/