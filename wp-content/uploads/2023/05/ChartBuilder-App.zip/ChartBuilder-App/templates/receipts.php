/**
* A PHP file that represents the template for displaying user purchase receipts.
*/