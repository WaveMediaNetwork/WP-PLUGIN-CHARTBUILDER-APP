/**
* A PHP file that defines the template for the organization
* management page visible to administrators.
*/