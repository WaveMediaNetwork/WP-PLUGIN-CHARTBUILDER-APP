/**
* A PHP file that represents the template for displaying the user's created charts.
*/