/**
*  A PHP file that defines the WordPress admin page for creating, modifying, and displaying chord charts.
*/