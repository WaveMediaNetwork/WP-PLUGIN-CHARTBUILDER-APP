/**
* A PHP file that defines the WordPress admin page
* for managing user accounts, organization, and receipts.
*/